<?php
// SERVER B - RECEIVE FILE UPLOAD
echo "SERVER B FILE UPLOAD - ";
echo move_uploaded_file($_FILES['upload']['tmp_name'], $_FILES['upload']['name'])
  ? "OK" : "ERROR" ;